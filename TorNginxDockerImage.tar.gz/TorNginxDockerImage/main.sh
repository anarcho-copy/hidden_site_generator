#!/bin/bash

if [ "$1" == "generate" ]
then
    if [ -f /web/private_key ]
    then
        echo '[-] You already have an private key, delete it if you want to generate a new key'
        exit -1
    fi
    if [ -z "$2" ]
    then
        echo '[-] You dont provided any mask, please inform an mask to generate your address'
        exit -1
    else
        echo '[+] Generating the address with mask: '$2
        shallot -f /tmp/key $2
        echo '[+] '$(grep Found /tmp/key)
        grep 'BEGIN RSA' -A 99 /tmp/key > /web/private_key
    fi

    address=$(grep Found /tmp/key | cut -d ':' -f 2 )

	echo '[+] Generating nginx configuration for site '$address
	echo 'server {' > /web/site.conf
	echo '  listen 127.0.0.1:8080;' >> /web/site.conf
	echo '  server_name '$address';' >> /web/site.conf
	echo '}' >> /web/site.conf
fi

if [ "$1" == "serve" ]
then
    if [ ! -f /web/private_key ]
    then
        echo '[-] Please run this container with generate argument to initialize your web page'
        exit -1
    fi
    echo '[+] Initializing local clock'
    ntpdate -B -q 0.debian.pool.ntp.org
    echo '[+] Starting tor'
    tor -f /etc/tor/torrc &
    echo '[+] Starting nginx'
    nginx &
    # Monitor logs
    sleep infinity
fi
