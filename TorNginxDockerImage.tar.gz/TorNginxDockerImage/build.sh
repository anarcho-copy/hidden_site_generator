#!/bin/bash

docker build -t tor-docker .
